##########################################################################
Subroza
##########################################################################

Author: Evil Angel
##########################################################################

Version: 2.4.1
##########################################################################

License: Creative Commons Attribution - Non - Commercial - Share Alike 3.0
##########################################################################

About:
###########################################################################

Subroza is a Rainmeter theme with a concept of Minimal desktop look for clean rich environment with a Date-Time-Day clock, an audio visualizer,a custom trash bin and System resource info. 
An in-built settings option is provided for changing the color scheme of the theme according to the user choice.
############################################################################

Requirements:
############################################################################
1. Windows 10 Version.1904 or higher
2. Rainmeter

(Rainmeter Link: https://www.rainmeter.net)

############################################################################

Installation:
#############################################################################
(Note: Rainmeter must be installed in the computer to use the theme pack)

1.Download the pack
2.Extract the pack
(Make sure Rainmeter is running in the computer)
3.Double click on Subroza_2.4.1 theme pack
4.Then press Install
5.Theme will be imported in Rainmeter

(Note: 1. To open settings of the theme double click on the clock's middle divider bar or double click on the Audio Visualizer.
       2. Audio Visualizer won't respond until you are playing any audio or music. To check try playing any music of do system sound test to view the position default position
          is at the bottom center of the desktop right above the taskbar)
##############################################################################

What's New:

1.Audio Visualzer not responding fixed.
2.System Info(RAM Usage, CPU Usage, Storage, Network speed) are added.
3.Trash Bin not responding fixed

##############################################################################
